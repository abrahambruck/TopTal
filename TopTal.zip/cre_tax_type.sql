create table tax_type (
tt_tax_type        varchar2(10),
tt_tax_desc        varchar2(100),
--tt_agency_id       varchar2(10),
constraint pk_tax_type primary key (tt_tax_type)
);