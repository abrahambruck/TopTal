-- @drop_all_tables
--
drop sequence seq_address_master;
drop table tax_payment_ind;
drop table tax_payment_corp;
drop table business_owner;
drop table taxpayer_corp;
drop table taxpayer_ind;
drop table tax_agency;
drop table address_master;
drop table tax_type;
drop table TMP_TAXPAYER_CORP;
drop table TMP_BUSINESS_OWNER;
