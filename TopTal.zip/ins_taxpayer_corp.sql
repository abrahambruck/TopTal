prompt Importing table TAXPAYER_CORP...
set feedback off
set define off
insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (47, 'TopCat LLC', to_date('03-08-2017', 'dd-mm-yyyy'), 'www.topcat.biz', 6, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (74, 'Loui''s Pizza', to_date('01-08-2009', 'dd-mm-yyyy'), null, 5, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (99, 'Papa Pap''s ', to_date('01-08-1992', 'dd-mm-yyyy'), 'www.pppp.net', 3, 2);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (88, 'FUBU LLC', to_date('03-08-2017', 'dd-mm-yyyy'), 'www.topcat.biz', 6, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (77, 'Phebe''s Pizza', to_date('01-08-2009', 'dd-mm-yyyy'), null, 5, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (66, 'Papa''s Bag', to_date('01-08-1992', 'dd-mm-yyyy'), 'www.pppp.net', 3, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (44, 'JJ and JJ Inc', to_date('03-08-2017', 'dd-mm-yyyy'), 'www.topcat.biz', 6, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (33, 'Inda Junga Corp', to_date('01-08-2009', 'dd-mm-yyyy'), null, 5, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (22, 'Atta Thorld', to_date('01-08-1992', 'dd-mm-yyyy'), 'www.pppp.net', 3, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (11, 'Monti''s Python', to_date('03-08-2017', 'dd-mm-yyyy'), 'www.topcat.biz', 6, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (111, 'Oracle LLC', to_date('01-08-2009', 'dd-mm-yyyy'), null, 5, 1);

insert into TAXPAYER_CORP (TC_CUIT_NUMBER, TC_CORP_NAME, TC_START_DATE, TC_WEBSITE, TC_ADDRESS_ID, TC_OWNER_ID)
values (222, 'Corp Inc', to_date('01-08-1992', 'dd-mm-yyyy'), 'www.pppp.net', 3, 1);

prompt Done.
