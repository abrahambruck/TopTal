--  @ins_all_tables
--
@ins_tax_type;
@ins_address_master;
@ins_taxpayer_ind;
@ins_taxpayer_corp;
@ins_business_owner;
@ins_tax_agency;
@ins_tax_payment_ind;
@ins_tax_payment_corp;
@ins_TMP_BUSINESS_OWNER;
@ins_TMP_TAXPAYER_CORP;
