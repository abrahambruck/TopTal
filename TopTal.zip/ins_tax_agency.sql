prompt Importing table TAX_AGENCY...
set feedback off
set define off
insert into TAX_AGENCY (TA_AGENCY_NUMBER, TA_CONTACT_PERSON, TA_ADDRESS_ID, TA_NO_EMPLOYEES)
values (161, 'George MacDonald', 4, 6);

insert into TAX_AGENCY (TA_AGENCY_NUMBER, TA_CONTACT_PERSON, TA_ADDRESS_ID, TA_NO_EMPLOYEES)
values (160, 'Mary Kontrari', 5, 631);

insert into TAX_AGENCY (TA_AGENCY_NUMBER, TA_CONTACT_PERSON, TA_ADDRESS_ID, TA_NO_EMPLOYEES)
values (501, 'Henry Ford XXII', 3, 99);

prompt Done.
